using UnityEngine;

[System.Serializable]
public class Save
{
    public int Number_Pigs;
    public int Upgrade_Cost;
    public int add_cost;
    public bool bought;
    public int money;
}