using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

[RequireComponent(typeof(GameData))]
public class SaveScript : MonoBehaviour
{
    public GameData gameData;
    public string savePath;
    public string extention;

    // Start is called before the first frame update
    void Start()
    {
        gameData = GetComponent<GameData>();
        savePath = Application.persistentDataPath + "/gamesave.save";

    }

    // Update is called once per frame
    public void SaveData()
    {
        Debug.Log(gameData.name);
        savePath = Application.persistentDataPath + "/gamesave." + extention;
        var save = new Save()
        {
            Number_Pigs = gameData.Number_Pigs,
            Upgrade_Cost = gameData.Upgrade_Cost,
            add_cost = gameData.add_cost,
            bought = gameData.bought,
            money = gameData.money
        };

        var binaryFormatter = new BinaryFormatter();
        using (var fileStream = File.Create(savePath))
        {
            binaryFormatter.Serialize(fileStream, save);
        }
        Debug.Log("data_saved    " + savePath);
    }


    public void LoadData()
    {
        savePath = Application.persistentDataPath + "/gamesave." + extention;
        if (File.Exists(savePath))
        {
            Save save;

            var binaryFormatter = new BinaryFormatter();
            using (var fileStream = File.Open(savePath, FileMode.Open))
            {
                save = (Save)binaryFormatter.Deserialize(fileStream);
            }

            gameData.Number_Pigs = save.Number_Pigs;
            gameData.Upgrade_Cost = save.Upgrade_Cost;
            gameData.add_cost = save.add_cost;
            gameData.bought = save.bought;
            gameData.money = save.money;
            Debug.Log("Data Loaded");


        }
        else
        {
            Debug.LogWarning("Save File Does Not Exist");
        }
              
    }
}
