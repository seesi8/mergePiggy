using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Load : MonoBehaviour
{
    public GameObject SaveScriptobj1;
    public GameObject SaveScriptobj2;
    public GameObject SaveScriptobj3;
    public GameObject SaveScriptobj4;
    public GameObject SaveScriptobj5;
    public GameObject SaveScriptobj6;
    public GameObject SaveScriptobj7;
    public GameObject SaveScriptobj8;
    public GameObject SaveScriptobj9;
    void Awake()
    {
        SaveScriptobj1.GetComponent<SaveScript>().LoadData();
        SaveScriptobj2.GetComponent<SaveScript>().LoadData();
        SaveScriptobj3.GetComponent<SaveScript>().LoadData();
        SaveScriptobj4.GetComponent<SaveScript>().LoadData();
        SaveScriptobj5.GetComponent<SaveScript>().LoadData();
        SaveScriptobj6.GetComponent<SaveScript>().LoadData();
        SaveScriptobj7.GetComponent<SaveScript>().LoadData();
        SaveScriptobj8.GetComponent<SaveScript>().LoadData();
        SaveScriptobj9.GetComponent<SaveScript>().LoadData();
    }
}
