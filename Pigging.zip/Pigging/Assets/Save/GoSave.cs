using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GoSave : MonoBehaviour
{
    public GameObject SaveScriptobj1;
    public GameObject SaveScriptobj2;
    public GameObject SaveScriptobj3;
    public GameObject SaveScriptobj4;
    public GameObject SaveScriptobj5;
    public GameObject SaveScriptobj6;
    public GameObject SaveScriptobj7;
    public GameObject SaveScriptobj8;
    public GameObject SaveScriptobj9;
    void Update()
    {
        SaveScriptobj1.GetComponent<SaveScript>().SaveData();
        SaveScriptobj2.GetComponent<SaveScript>().SaveData();
        SaveScriptobj3.GetComponent<SaveScript>().SaveData();
        SaveScriptobj4.GetComponent<SaveScript>().SaveData();
        SaveScriptobj5.GetComponent<SaveScript>().SaveData();
        SaveScriptobj6.GetComponent<SaveScript>().SaveData();
        SaveScriptobj7.GetComponent<SaveScript>().SaveData();
        SaveScriptobj8.GetComponent<SaveScript>().SaveData();
        SaveScriptobj9.GetComponent<SaveScript>().SaveData();
    }

}
