using UnityEngine;
using UnityEngine.UI;

public class GameData : MonoBehaviour
{
    public int Number_Pigs;
    public GameObject Pig_Maker;
    public GameObject Buy_Upgrade;
    public int Upgrade_Cost;
    public int add_cost;
    public bool bought;
    public int money = 125;
    public GameObject money_tracker;
 
    void Update()
    {
        money = money_tracker.GetComponent<Money_Tracker>().money;
        Upgrade_Cost = Buy_Upgrade.GetComponent<Buy_Upgrade>().upgrade_cost;
        Number_Pigs = Pig_Maker.GetComponent<Pig_maker>().Number_Pigs;
        add_cost = Pig_Maker.GetComponent<Pig_maker>().cost;
        bought = Buy_Upgrade.GetComponent<Buy_Upgrade>().Bought;
    }
    void Awake()
    {

        Debug.Log("loaded" + Upgrade_Cost);
        money = 1000000000;
        money_tracker.GetComponent<Money_Tracker>().money = money;
        Buy_Upgrade.GetComponent<Buy_Upgrade>().upgrade_cost = Upgrade_Cost;
        Pig_Maker.GetComponent<Pig_maker>().Number_Pigs = Number_Pigs;
        Pig_Maker.GetComponent<Pig_maker>().cost = add_cost;
        Buy_Upgrade.GetComponent<Buy_Upgrade>().Bought = bought;

    }
}

