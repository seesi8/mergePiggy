using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Money_Tracker : MonoBehaviour
{
    public int money = 500;
    void Start()
    {

    }
    void Update()
    {
        GetComponent<UnityEngine.UI.Text>().text = money.ToString();
    }
}
