using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Pig_maker : MonoBehaviour
{
    public GameObject pig;
    public Vector2 minBounds;
    public GameObject money_tracker;
    public Vector2 maxBounds;
    public int cost;
    public GameObject Cost_Tracker;
    public GameObject no_money;
    public int Number_Pigs;
    public int i;
    public void Start()
    {
        Cost_Tracker.GetComponent<UnityEngine.UI.Text>().text = cost.ToString();
        while (i < Number_Pigs)
        {
            Vector2 newPos = new Vector2();
            Debug.Log(Number_Pigs);
            newPos.x = Random.Range(minBounds.x, maxBounds.x);
            newPos.y = Random.Range(minBounds.y, maxBounds.y);
            Debug.Log("created");
            Instantiate(pig, newPos, Quaternion.identity);
            i++;
        }
    }
    public void spawn()
    {
        if (money_tracker.GetComponent<Money_Tracker>().money - cost > -1)
        {
            money_tracker.GetComponent<Money_Tracker>().money -= cost;
            Vector2 newPos = new Vector2();
            newPos.x = Random.Range(minBounds.x, maxBounds.x);
            newPos.y = Random.Range(minBounds.y, maxBounds.y);
            Debug.Log("created");
            Instantiate(pig, newPos, Quaternion.identity);

            cost = cost * 2;
            Cost_Tracker.GetComponent<UnityEngine.UI.Text>().text = cost.ToString();
            Number_Pigs += 1;
        }
        else
        {
            Debug.Log("You Don't Have That Type Of Cash");
            
            
            no_money.SetActive(true);
            Invoke("Money_Out", 2.0f);//this will happen after 2 seconds

        }
        
    }
    public void Money_Out()
    {
        no_money.SetActive(false);
    }
    
}
