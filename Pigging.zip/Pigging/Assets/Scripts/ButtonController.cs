using System.Collections;
using UnityEngine;

public class ButtonController : MonoBehaviour
{
    [SerializeField] private GameObject _ui;
    public bool cloased;
    public void Go()
    {
        Debug.Log("trying");
        Debug.Log(cloased);
        if (cloased == false)
        {
            _ui.SetActive(false);
            cloased = true;
        }
        else
        {
            Debug.Log("open");
            _ui.SetActive(true);
            cloased = false;
        }
    }
}
