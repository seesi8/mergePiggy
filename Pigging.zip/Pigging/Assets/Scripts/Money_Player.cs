using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Money_Player : MonoBehaviour
{
    public float interval;

    public GameObject money_tracker;
    public int money;
    public float speed = 1;
    public int Money_Per_Time = 1;
    void Start()
    {
        InvokeRepeating("make", 10f, interval);
    }
    void make()
    {
        money_tracker.GetComponent<Money_Tracker>().money += Money_Per_Time;
    }
    public void cancel()
    {
        speed *= 0.90f;
        CancelInvoke();
        if (interval * speed > .00001)
        {
            interval = interval * speed;
            InvokeRepeating("make", 1f, interval);
        }

    }
    void Update()
    {
    }
}
