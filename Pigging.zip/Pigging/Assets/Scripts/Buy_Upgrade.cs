using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Buy_Upgrade : MonoBehaviour
{
    public GameObject button;
    public GameObject add;
    public GameObject money_tracker;
    public int buy_cost;
    public bool Bought = false;
    public int upgrade_cost;
    public GameObject pig;
    public GameObject no_money;
    public GameObject Cost_Tracker;
    public GameObject Add_Controller;
    void Start()
    {
        Cost_Tracker.GetComponent<UnityEngine.UI.Text>().text = buy_cost.ToString();
        if (Bought == true)
        {
            pig.SetActive(true);
            button.GetComponent<UnityEngine.UI.Text>().text = "upgrade";
            button.GetComponent<UnityEngine.UI.Text>().fontSize = 50;
            add.SetActive(true);
            Bought = true;
            Cost_Tracker.GetComponent<UnityEngine.UI.Text>().text = upgrade_cost.ToString();
        }
    }
    public void clicked()
    {
        Debug.Log(Bought);
        if (Bought == false)
            {
            if (money_tracker.GetComponent<Money_Tracker>().money - buy_cost > -1)
            {
                pig.SetActive(true);
                money_tracker.GetComponent<Money_Tracker>().money -= buy_cost;
                button.GetComponent<UnityEngine.UI.Text>().text = "upgrade";
                button.GetComponent<UnityEngine.UI.Text>().fontSize = 50;
                add.SetActive(true);
                Bought = true;
                Cost_Tracker.GetComponent<UnityEngine.UI.Text>().text = upgrade_cost.ToString();
                Add_Controller.GetComponent<Pig_maker>().Number_Pigs += 1;
                return;
            }
            else
            {
                Debug.Log("You Don't Have That Type Of Cash");
                no_money.SetActive(true);
                Invoke("Money_Out", 2.0f);//this will happen after 2 seconds
            }
            return;

        }
        if (Bought == true)
        {
            if (money_tracker.GetComponent<Money_Tracker>().money - upgrade_cost > -1)
            {
                
                if (pig.GetComponent<Money_Player>().interval * 0.90f > .00001f)
                    {
                    money_tracker.GetComponent<Money_Tracker>().money -= upgrade_cost;
                    Debug.Log(money_tracker.GetComponent<Money_Tracker>().money);
                    upgrade_cost *= 2;
                    pig.GetComponent<Money_Player>().cancel();
                    
                    Cost_Tracker.GetComponent<UnityEngine.UI.Text>().text = upgrade_cost.ToString();
                    return;
                }
                else
                    button.GetComponent<UnityEngine.UI.Text>().text = "MAX";

            }
            else
            {
                Debug.Log("You Don't Have That Type Of Cash");
                no_money.SetActive(true);
                Invoke("Money_Out", 2.0f);//this will happen after 2 seconds
            }
            return;
        }

    }
    public void Money_Out()
    {
        no_money.SetActive(false);
    }
}
